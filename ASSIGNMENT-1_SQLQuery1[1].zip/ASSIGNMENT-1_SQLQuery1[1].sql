
--ASSIGNMENT-1

Create DATABASE MyDatabase;
USE MyDatabase
Go

	-- 1) TABLE-1
CREATE TABLE Salesman (
Salesman_ID INT NOT NULL,
Salesman_Name VARCHAR(50),
Commission INT,
City VARCHAR(50),
Age INT,
);

INSERT INTO Salesman (Salesman_ID, Salesman_Name, Commission, City, Age)
VALUES
(101, 'Joe', 50, 'California', 17),
(102, 'Simon', 75, 'Texas', 25),
(103, 'Jessie', 105, 'Florida', 35),
(104, 'Danny', 100, 'Texas', 22),
(105, 'Lia', 65, 'New Jersey', 30);


SELECT * FROM Salesman

--2) TABLE-2
CREATE TABLE Customer (
SalesmanId INT,
CustomerId INT,
CustomerName VARCHAR(50),
PurchaseAmount INT,
);


INSERT INTO Customer (SalesmanId, CustomerId, CustomerName, PurchaseAmount)
VALUES
(101, 2345, 'Andrew', 550),
(103, 1575, 'Lucky', 4500),
(104, 2345, 'Andrew', 4000),
(107, 3747, 'Remona', 2700),
(110, 4004, 'Julia', 4545);

SELECT * FROM Customer;

--3) Table 3
CREATE TABLE Orders (OrderId int, CustomerId int, SalesmanId int, Orderdate Date, Amount
money);

INSERT INTO Orders (OrderId, CustomerId, SalesmanId, Orderdate, Amount)
Values
(5001,2345,101,'2021-07-01',550),
(5003,1234,105,'2022-02-15',1500)

SELECT * FROM Orders;


--Tasks performance

--TASK-1

INSERT INTO Orders (OrderId, CustomerId, SalesmanId, Orderdate, Amount)
VALUES (5005, 1575, 103, '2023-08-22', 2000);

--Task - 2
--ADD Primary Key
ALTER TABLE Salesman
ADD CONSTRAINT PK_Salesman PRIMARY KEY (Salesman_ID);

--ADD default constrain
ALTER TABLE Salesman
ADD CONSTRAINT DF_City DEFAULT 'Unknown' FOR City;

--Add Foreign Key for SalesmanId in Customer table
ALTER TABLE Customer
ADD CONSTRAINT FK_Customer_Salesman FOREIGN KEY (SalesmanId)
REFERENCES Salesman(Salesman_ID);

DELETE FROM Customer
WHERE SalesmanId IN (107, 110);

--Add NOT NULL constraint for CustomerName
ALTER TABLE Customer
ALTER COLUMN CustomerName VARCHAR(255) NOT NULL;

--TASK-3..... Fetch customers ending with �N� and purchase > 500

SELECT CustomerName, PurchaseAmount
FROM Customer
WHERE CustomerName LIKE '%N'
  AND PurchaseAmount > 500;


--TASK-4..... SET operatoer on SalesmanId
-- Unique SalesmanId from both tables (UNION removes duplicates)
SELECT Salesman_ID FROM Salesman
UNION
SELECT SalesmanId FROM Customer;

-- SalesmanId with duplicates (UNION ALL keeps duplicates)
SELECT Salesman_ID FROM Salesman
UNION ALL
SELECT SalesmanId FROM Customer;


--Task; 05
SELECT o.Orderdate, s.Salesman_Name, c.CustomerName, s.Commission, s.City
FROM Orders o
JOIN Salesman s ON o.SalesmanId = s.Salesman_ID
JOIN Customer c ON o.CustomerId = c.CustomerId
WHERE c.PurchaseAmount BETWEEN 500 AND 1500;

--Task- 06: RIGHT JOIN Sales man and order ID
SELECT s.Salesman_ID, s.Salesman_Name, o.OrderId, o.Amount, o.Orderdate
FROM Salesman s
RIGHT JOIN Orders o ON s.Salesman_ID = o.SalesmanId;
USE assignment_1

